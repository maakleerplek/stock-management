import{r as o,b7 as r,j as e}from"./index-DjOBj_Ai.js";import{Wrapper as a}from"./Layout-B7Uh6xkA.js";import{a as s}from"./ThemeContext-BjJu0IKI.js";function f(){const t=s();return o.useEffect(()=>{r(t)},[]),e.jsx(a,{titleText:"Logging out",loader:!0})}export{f as default};
//# sourceMappingURL=Logout-BKSQTIDs.js.map
