import{j as o,ac as s}from"./index-DjOBj_Ai.js";import{a}from"./IconChevronDown-I6OOyduR.js";import{I as t}from"./IconChevronRight-BBTCuiZt.js";function m({enabled:n,expanded:r}){return o.jsx(s,{size:"sm",variant:"transparent",disabled:!n,children:r?o.jsx(a,{}):o.jsx(t,{})})}export{m as R};
//# sourceMappingURL=RowExpansionIcon-CUnOv-Ch.js.map
