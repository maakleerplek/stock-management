import{K as t,az as a,r as s}from"./index-DjOBj_Ai.js";/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const n=[["path",{d:"M20 6a1 1 0 0 1 1 1v10a1 1 0 0 1 -1 1h-11l-5 -5a1.5 1.5 0 0 1 0 -2l5 -5z",key:"svg-0"}],["path",{d:"M12 10l4 4m0 -4l-4 4",key:"svg-1"}]],c=t("outline","backspace","Backspace",n);function r(){const e=a();return s.useMemo(()=>e.getSetting("INVENTREE_INSTANCE","InvenTree"),[e])}export{c as I,r as u};
//# sourceMappingURL=UseInstanceName-tQvebO4s.js.map
