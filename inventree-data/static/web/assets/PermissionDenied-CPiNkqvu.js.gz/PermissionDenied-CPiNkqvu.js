import{j as s,ab as r}from"./index-DjOBj_Ai.js";import{E as i}from"./GenericErrorPage-BWQWzpn2.js";function t(){return s.jsx(i,{title:r._({id:"JUwB5j"}),message:r._({id:"H//rsn"})})}export{t as P};
//# sourceMappingURL=PermissionDenied-CPiNkqvu.js.map
