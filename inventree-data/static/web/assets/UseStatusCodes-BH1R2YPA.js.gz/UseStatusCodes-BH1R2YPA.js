import{bQ as u,r}from"./index-DjOBj_Ai.js";import{a9 as c}from"./Filter-CpWhllKn.js";function i({modelType:e}){const a=u.getState().status;return r.useMemo(()=>{const t=c(e)||null,s={};return t&&Object.keys(t.values).forEach(o=>{s[o]=t.values[o].key}),s},[e,a])}export{i as u};
//# sourceMappingURL=UseStatusCodes-BH1R2YPA.js.map
