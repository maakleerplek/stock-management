import{K as e}from"./index-DjOBj_Ai.js";/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=[["path",{d:"M15 6l-6 6l6 6",key:"svg-0"}]],n=e("outline","chevron-left","ChevronLeft",o);export{n as I};
//# sourceMappingURL=IconChevronLeft-BZQuVB3G.js.map
