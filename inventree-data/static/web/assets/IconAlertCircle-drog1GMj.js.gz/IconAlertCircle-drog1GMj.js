import{K as e}from"./index-DjOBj_Ai.js";/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=[["path",{d:"M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0",key:"svg-0"}],["path",{d:"M12 8v4",key:"svg-1"}],["path",{d:"M12 16h.01",key:"svg-2"}]],a=e("outline","alert-circle","AlertCircle",t);export{a as I};
//# sourceMappingURL=IconAlertCircle-drog1GMj.js.map
