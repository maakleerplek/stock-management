import{c$ as o,r as s,j as c,ab as r,cS as n}from"./index-DjOBj_Ai.js";import{Wrapper as i}from"./Layout-B7Uh6xkA.js";import{a as u,u as p}from"./ThemeContext-BjJu0IKI.js";function g(){const t=u(),e=p(),a=o(n,300);return s.useEffect(()=>{a(t,e?.state)},[t]),c.jsx(i,{titleText:r._({id:"ps9k8Y"}),loader:!0})}export{g as default};
//# sourceMappingURL=LoggedIn-bKdYqCBf.js.map
