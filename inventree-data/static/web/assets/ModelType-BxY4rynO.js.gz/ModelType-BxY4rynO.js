import{aC as e}from"./index-DjOBj_Ai.js";function a(l){return{...e[l],label:e[l].label(),label_multiple:e[l].label_multiple()}}export{a as g};
//# sourceMappingURL=ModelType-BxY4rynO.js.map
