import{j as r,ab as o}from"./index-DjOBj_Ai.js";import{E as t}from"./GenericErrorPage-BWQWzpn2.js";import"./ThemeContext-BjJu0IKI.js";function a(){return r.jsx(t,{title:o._({id:"boJlGf"}),message:o._({id:"CcD0eu"})})}export{a as default};
//# sourceMappingURL=NotFound-BksZ8Fp_.js.map
